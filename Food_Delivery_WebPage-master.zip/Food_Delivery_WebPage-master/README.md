# Food_Delivery_WebPage
Reponsive Bakery Food Delivery WebPage using HTML and CSS.
#### It is a webpage using pure HTML and CSS having navigation bar which changes colour when hover over it.We maade it responsive by using Media Query.
Its contains a header located at the top of the website . It also contains a logo representing the Bakery!
A navigation bar contains a list of links to help visitors navigating through your website.
![webpage_1](https://user-images.githubusercontent.com/54896331/107781509-fbe6c580-6d6d-11eb-81bf-1007e2616d39.png)
#### The Layout of the page is there which contain the contents in well arranged way in 3 columns having the services of the bakery.Here there are three blocks containing information about the bakery and menu. 
![webpage_2](https://user-images.githubusercontent.com/54896331/107783205-030ed300-6d70-11eb-9720-0612b43990ea.png)
#### Its having the list of the clients and patners connected with the Bakery.
![webpage_3](https://user-images.githubusercontent.com/54896331/107784440-77964180-6d71-11eb-9d6b-ecaeca167a9a.png)
#### This Section contains the Form to fill in details of the Customer.At the Bottom of the WebPage it contains the Footer contains information like copyright and contact info
![webpage_4](https://user-images.githubusercontent.com/54896331/107787007-8d593600-6d74-11eb-9072-adc84873874e.png)




